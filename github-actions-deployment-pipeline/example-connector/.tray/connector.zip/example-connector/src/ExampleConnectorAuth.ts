export type ExampleConnectorAuth = never; // No Authentication
