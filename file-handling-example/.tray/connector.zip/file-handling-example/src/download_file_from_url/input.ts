export type DownloadFileFromUrlInput = {
  file_url: string;
};
